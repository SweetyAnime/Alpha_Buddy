package com.nk.alphabuddy

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class EngChemistry : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_eng_chemistry)
    }
}