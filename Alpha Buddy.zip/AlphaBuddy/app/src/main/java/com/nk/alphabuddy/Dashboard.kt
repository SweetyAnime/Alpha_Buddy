package com.nk.alphabuddy

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.view.View
import android.widget.ImageButton

class Dashboard : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        // Hide the ActionBar
        supportActionBar?.hide()

       //studymaterials image button
        val studyMaterialsButton: ImageButton = findViewById(R.id.studymaterials)
        studyMaterialsButton.setOnClickListener(View.OnClickListener {
            val intent = Intent(this@Dashboard, Studymaterial::class.java)
            startActivity(intent)
        })





    }
}