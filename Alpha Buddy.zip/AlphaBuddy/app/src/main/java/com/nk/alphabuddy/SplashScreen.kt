package com.nk.alphabuddy

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler

@Suppress("DEPRECATION")
@SuppressLint("CustomSplashScreen")
class SplashScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)

        // Hide the ActionBar
        supportActionBar?.hide()

        // Delay for 3 seconds and start the Dashboard activity
        Handler().postDelayed({
            val intent = Intent(this@SplashScreen, Dashboard::class.java)
            startActivity(intent)
            finish() // Optional, to remove the SplashScreen from the back stack
        }, 3000) // 3000 milliseconds (3 seconds)
    }
}
